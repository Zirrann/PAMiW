﻿using Microsoft.AspNetCore.Mvc;
using ELibrary.Models;
using System.Linq;

namespace ELibrary.Controllers
{
    public class ChartController : Controller
    {
        private readonly JsonFileHandler _jsonFileHandler;

        public ChartController(IWebHostEnvironment env)
        {
            var filePath = Path.Combine(env.ContentRootPath, "App_Data", "books.json");
            _jsonFileHandler = new JsonFileHandler(filePath);
        }

        // GET: /Chart
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetBookCountsByGenre()
        {
            var books = _jsonFileHandler.LoadBooks();
            var bookCountsByGenre = books
                .GroupBy(b => b.Genre)
                .Select(g => new
                {
                    Genre = g.Key,
                    Count = g.Count()
                })
                .OrderBy(g => g.Genre) // Optional: Order by genre
                .ToList();

            return Json(bookCountsByGenre);
        }
    }
}
